import IAutoCompleteItem from './IAutoCompleteItem';

export { IAutoCompleteItem };
