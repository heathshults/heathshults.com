export default interface IAutoCompleteItem {
  text: string;
}
