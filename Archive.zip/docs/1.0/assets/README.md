# Assets

Directory dedicated to your images, icons, and fonts.

## Loading an asset

Like in classic HTML, assets are available in documents like this:

```html
<img src="/assets/my-image.jpg" alt="A beautiful image" />
```
