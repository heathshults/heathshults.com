<div class="bd-callout bd-callout-warning">
<h4 id="asynchronous-methods-and-transitions">Asynchronous methods and transitions</h4>
<p>All API methods are <strong>asynchronous</strong> and start a <strong>transition</strong>. They return to the caller as soon as the transition is started but <strong>before it ends</strong>. In addition, a method call on a <strong>transitioning component will be ignored</strong>.</p>
<p><a href="{{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/getting-started/javascript/">See our JavaScript documentation for more information.</a>
</p></div>
