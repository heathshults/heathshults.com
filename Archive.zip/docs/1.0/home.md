<div class="frmkt-col-md-12 frmkt-blaster-banner frmkt-flexi-container frmkt-align-items-center">
  <div class="frmkt-the-dna-wrapper">
    <!-- css-only-dna-->
    <div class="frmkt-dna-conainer">
        <div class="frmkt-dna">
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
          <div class="frmkt-ele"></div>
        </div>
      </div>
      <!-- css-only-dna-->
  </div>
  <div class="frmkt-container frmkt-blast-banner-content" style="margin-left: 100px">
    <div class="frmkt-row">
      <div class="frmkt-col-md-12">

# <span class="frmkt-black-box">{{ title }}</span>

<span class="frmkt-black-box bd-lead">{{ description }}</span>

<span class="frmkt-black-box bd-lead">Do _More._ Accomplish _More._</span>

<a href="javascript:void(0)" class="frmkt-btn frmkt-btn-primary">Learn More</a>
<a href="javascript:void(0)" class="frmkt-btn frmkt-btn-primary">Download Now</a>

</div>
</div>
</div>
</div>
