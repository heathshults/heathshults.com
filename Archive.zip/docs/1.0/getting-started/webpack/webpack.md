# Installing framekit

[Install framekit]({{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/getting-started/download/#npm) as a Node.js module using npm.

## Importing JavaScript

Import [framekit's JavaScript]({{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/getting-started/javascript/) by adding this line to your app's entry point (usually `index.js` or `app.js`):

```js
import 'framekit'
```

Alternatively, you may **import plugins individually** as needed:

```js
import 'framekit/js/dist/util'
import 'framekit/js/dist/dropdown'
...
```

framekit is dependent on [jQuery](https://jquery.com/) and [Popper](https://popper.js.org/),
these are defined as `peerDependencies`, this means that you will have to make sure to add both of them
to your `package.json` using `npm install --save jquery popper.js`.

<div class="bd-callout bd-callout-warning">
Notice that if you chose to **import plugins individually**, you must also install [exports-loader](https://github.com/webpack-contrib/exports-loader)
</div>


## Importing Styles

### Importing Precompiled Sass

To enjoy the full potential of framekit and customize it to your needs, use the source files as a part of your project's bundling process.

First, create your own `_custom.scss` and use it to override the [built-in custom variables]({{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/getting-started/options/). Then, use your main Sass file to import your custom variables, followed by framekit:

```scss
@import "custom";
@import "~framekit/scss/framekit";
```

For framekit to compile, make sure you install and use the required loaders: [sass-loader](https://github.com/webpack-contrib/sass-loader), [postcss-loader](https://github.com/postcss/postcss-loader) with [Autoprefixer](https://github.com/postcss/autoprefixer#webpack). With minimal setup, your webpack config should include this rule or similar:

```js
  ...
  {
    test: /\.(scss)$/,
    use: [{
      loader: 'style-loader', // inject CSS to page
    }, {
      loader: 'css-loader', // translates CSS into CommonJS modules
    }, {
      loader: 'postcss-loader', // Run post css actions
      options: {
        plugins: function () { // post css plugins, can be exported to postcss.config.js
          return [
            require('precss'),
            require('autoprefixer')
          ];
        }
      }
    }, {
      loader: 'sass-loader' // compiles Sass to CSS
    }]
  },
  ...
```

### Importing Compiled CSS

Alternatively, you may use framekit's ready-to-use CSS by simply adding this line to your project's entry point:

```js
import 'framekit/dist/css/framekit.min.css'
```

In this case you may use your existing rule for `css` without any special modifications to webpack config, except you don't need `sass-loader` just [style-loader](https://github.com/webpack-contrib/style-loader) and [css-loader](https://github.com/webpack-contrib/css-loader).

```js
  ...
  module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      }
    ]
  }
  ...
```
