We've designed and developed framekit to work in a number of environments. Here are some of the best practices we've gathered from years of working on and using it ourselves.

<div class="bd-callout bd-callout-warning">
**Heads up!** This copy is a work in progress.
</div>


### General outline

- Working with CSS
- Working with Sass files
- Building new CSS components
- Working with flexbox
- Ask in [Slack](https://framekit-slack.herokuapp.com/)
