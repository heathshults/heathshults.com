---
layout: docs
title: Download
description: Download framekit to get the compiled CSS and JavaScript, source code, or include it with your favorite package managers like npm, RubyGems, and more.
group: getting-started
toc: true
---

## Compiled CSS and JS

Download ready-to-use compiled code for **framekit v{{ shared.current_version }}** to easily drop into your project, which includes:

- Compiled and minified CSS bundles (see [CSS files comparison]({{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/getting-started/contents/#css-files))
- Compiled and minified JavaScript plugins

This doesn't include documentation, source files, or any optional JavaScript dependencies (jQuery and Popper.js).

<a href="{{ shared.download.dist }}" class="frmkt-btn frmkt-btn-frmkt-primary" onclick="ga('send', 'event', 'Getting started', 'Download', 'Download framekit');">Download</a>

## Source files

Compile framekit with your own asset pipeline by downloading our source Sass, JavaScript, and documentation files. This option requires some additional tooling:

- Sass compiler (Libsass or Ruby Sass is supported) for compiling your CSS.
- [Autoprefixer](https://github.com/postcss/autoprefixer) for CSS vendor prefixing

Should you require [build tools]({{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/getting-started/build-tools/#tooling-setup), they are included for developing framekit and its docs, but they're likely unsuitable for your own purposes.

<a href="{{ shared.download.source }}" class="frmkt-btn frmkt-btn-frmkt-primary" onclick="ga('send', 'event', 'Getting started', 'Download', 'Download source');">Download source</a>

## framekitCDN

Skip the download with [framekitCDN](https://www.framekitcdn.com/) to deliver cached version of framekit's compiled CSS and JS to your project.

```html
<link rel="stylesheet" href="{{ shared.cdn.css }}" integrity="{{ shared.cdn.css_hash }}" crossorigin="anonymous">
<script src="{{ shared.cdn.js }}" integrity="{{ shared.cdn.js_hash }}" crossorigin="anonymous"></script>
```

If you're using our compiled JavaScript, don't forget to include CDN versions of jQuery and Popper.js before it.

```html
<script src="{{ shared.cdn.jquery }}" integrity="{{ shared.cdn.jquery_hash }}" crossorigin="anonymous"></script>
<script src="{{ shared.cdn.popper }}" integrity="{{ shared.cdn.popper_hash }}" crossorigin="anonymous"></script>
```

## Package managers

Pull in framekit's **source files** into nearly any project with some of the most popular package managers. No matter the package manager, framekit will **require a Sass compiler and [Autoprefixer](https://github.com/postcss/autoprefixer)** for a setup that matches our official compiled versions.

### npm

Install framekit in your Node.js powered apps with [the npm package](https://www.npmjs.com/package/framekit):

```sh
npm install framekit
```

`require('framekit')` will load all of framekit's jQuery plugins onto the jQuery object. The `framekit` module itself does not export anything. You can manually load framekit's jQuery plugins individually by loading the `/js/*.js` files under the package's top-level directory.

framekit's `package.json` contains some additional metadata under the following keys:

- `sass` - path to framekit's main [Sass](https://sass-lang.com/) source file
- `style` - path to framekit's non-minified CSS that's been precompiled using the default settings (no customization)

### RubyGems

Install framekit in your Ruby apps using [Bundler](https://bundler.io/) (**recommended**) and [RubyGems](https://rubygems.org/) by adding the following line to your [`Gemfile`](https://bundler.io/gemfile.html):

```ruby
gem 'framekit', '~> {{ shared.current_ruby_version }}'
```

Alternatively, if you're not using Bundler, you can install the gem by running this command:

```sh
gem install framekit -v {{ shared.current_ruby_version }}
```

[See the gem's README](https://github.com/twbs/framekit-rubygem/blob/master/README.md) for further details.

### Composer

You can also install and manage framekit's Sass and JavaScript using [Composer](https://getcomposer.org/):

```sh
composer require twbs/framekit:{{ shared.current_version }}
```

### NuGet

If you develop in .NET, you can also install and manage framekit's [CSS](https://www.nuget.org/packages/framekit/) or [Sass](https://www.nuget.org/packages/framekit.sass/) and JavaScript using [NuGet](https://www.nuget.org/):

```powershell
Install-Package framekit
```

```powershell
Install-Package framekit.sass
```
