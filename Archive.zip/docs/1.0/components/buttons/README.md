<h1 id="views">Views</h1>
<p>This is where all of your pages and templates live.</p>
<h2 id="nunjucks">Nunjucks</h2>
<p>The starter kit uses a powerful (but optional) templating engine:
<a href="http://mozilla.github.io/nunjucks/">Nunjucks</a>.</p>
<p>The syntax is very close to traditional HTML, allowing designers and
developers alike to get comfortable with the code really quickly.</p>
<h2 id="pages">Pages</h2>
<p>Views are HTML or Nunjucks files, e.g. <code>index.html</code>, <code>filename.html</code>.
Each page is accessible at <code>http://your-domain/filename.html</code>.
Add as many as needed, and link between them like you would with classic HTML.</p>
<h2 id="templates-and-partials">Templates and partials</h2>
<p>A default template is provided in <a href="_template.html"><code>_template.html</code></a>.</p>
<p>Partials should have a name of the form <code>_partial.html</code> (e.g. <code>_page-header.html</code>).</p>
<h2 id="examples">Examples</h2>
<ul>
<li><a href="example.html"><code>example.html</code></a>: shows what you can achieve in minutes with the starter kit</li>
<li><a href="blank.html"><code>blank.html</code></a>: a blank template for you to easily create your own prototype</li>
<li><a href="workshop.html"><code>workshop.html</code></a>: boilerplate for the <a href="https://tdx-starter-kit.herokuapp.com/">TrailheaDX 2017 workshop</a></li>
<li><a href="workshop-done.html"><code>workshop-done.html</code></a>: what your page should look like when you’ve completed the workshop</li>
</ul>
