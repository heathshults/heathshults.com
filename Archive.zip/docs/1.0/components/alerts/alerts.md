<main class="frmkt-col-12 frmkt-col-md-9 frmkt-col-xl-8 frmkt-py-md-3 frmkt-pl-md-5 bd-content" role="main">
<h1 class="bd-title" id="content">Alerts</h1>
<p class="bd-lead">Provide contextual feedback messages for typical user actions with the handful of available and flexible alert messages.</p>

<h2 id="examples"><div>Examples<a class="frmkt-anchorjs-link frmkt-" href="#examples" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h2>

<p>Alerts are available for any length of text, as well as an optional dismiss button. For proper styling, use one of the eight <strong>required</strong> contextual classes (e.g., <code class="highlighter-rouge">.alert-success</code>). For inline dismissal, use the <a href="#dismissing">alerts jQuery plugin</a>.</p>

<div class="bd-example">

<div class="frmkt-alert frmkt-alert-primary" role="alert">
  A simple primary alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-secondary" role="alert">
  A simple secondary alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-success" role="alert">
  A simple success alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-danger" role="alert">
  A simple danger alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-warning" role="alert">
  A simple warning alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-info" role="alert">
  A simple info alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-light" role="alert">
  A simple light alert—check it out!
</div>
<div class="frmkt-alert frmkt-alert-dark" role="alert">
  A simple dark alert—check it out!
</div>
</div>
<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html"><span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-primary"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple primary alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-secondary"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple secondary alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-success"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple success alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-danger"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple danger alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-warning"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple warning alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-info"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple info alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-light"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple light alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-dark"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple dark alert—check it out!
<span class="frmkt-nt">&lt;/div&gt;</span></code></pre></figure>

<div class="bd-callout bd-callout-warning">
<h5 id="conveying-meaning-to-assistive-technologies">Conveying meaning to assistive technologies</h5>

<p>Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers. Ensure that information denoted by the color is either obvious from the content itself (e.g. the visible text), or is included through alternative means, such as additional text hidden with the <code class="highlighter-rouge">.sr-only</code> class.</p>
</div>

<h3 id="link-color"><div>Link color<a class="frmkt-anchorjs-link frmkt-" href="#link-color" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h3>

<p>Use the <code class="highlighter-rouge">.alert-link</code> utility class to quickly provide matching colored links within any alert.</p>

<div class="bd-example">

<div class="frmkt-alert frmkt-alert-primary" role="alert">
  A simple primary alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-secondary" role="alert">
  A simple secondary alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-success" role="alert">
  A simple success alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-danger" role="alert">
  A simple danger alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-warning" role="alert">
  A simple warning alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-info" role="alert">
  A simple info alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-light" role="alert">
  A simple light alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
<div class="frmkt-alert frmkt-alert-dark" role="alert">
  A simple dark alert with <a href="javascript:void(0)" class="frmkt-alert-link">an example link</a>. Give it a click if you like.
</div>
</div>
<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html"><span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-primary"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple primary alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-secondary"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple secondary alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-success"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple success alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-danger"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple danger alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-warning"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple warning alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-info"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple info alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-light"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple light alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span>
<span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-dark"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  A simple dark alert with <span class="frmkt-nt">&lt;a</span> <span class="frmkt-na">href=</span><span class="frmkt-s">"#"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-link"</span><span class="frmkt-nt">&gt;</span>an example link<span class="frmkt-nt">&lt;/a&gt;</span>. Give it a click if you like.
<span class="frmkt-nt">&lt;/div&gt;</span></code></pre></figure>

<h3 id="additional-content"><div>Additional content<a class="frmkt-anchorjs-link frmkt-" href="#additional-content" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h3>

<p>Alerts can also contain additional HTML elements like headings, paragraphs and dividers.</p>

<div class="bd-example">
<div class="frmkt-alert frmkt-alert-success" role="alert">
  <h4 class="frmkt-alert-heading">Well done!</h4>
  <p>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.</p>
  <hr>
  <p class="frmkt-mb-0">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p>
</div>
</div>
<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html"><span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-success"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  <span class="frmkt-nt">&lt;h4</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert-heading"</span><span class="frmkt-nt">&gt;</span>Well done!<span class="frmkt-nt">&lt;/h4&gt;</span>
  <span class="frmkt-nt">&lt;p&gt;</span>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.<span class="frmkt-nt">&lt;/p&gt;</span>
  <span class="frmkt-nt">&lt;hr&gt;</span>
  <span class="frmkt-nt">&lt;p</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"mb-0"</span><span class="frmkt-nt">&gt;</span>Whenever you need to, be sure to use margin utilities to keep things nice and tidy.<span class="frmkt-nt">&lt;/p&gt;</span>
<span class="frmkt-nt">&lt;/div&gt;</span></code></pre></figure>

<h3 id="dismissing"><div>Dismissing<a class="frmkt-anchorjs-link frmkt-" href="#dismissing" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h3>

<p>Using the alert JavaScript plugin, it’s possible to dismiss any alert inline. Here’s how:</p>

<ul>
  <li>Be sure you’ve loaded the alert plugin, or the compiled framekit JavaScript.</li>
  <li>If you’re building our JavaScript from source, it <a href="/getting-started/javascript/#util">requires <code class="highlighter-rouge">util.js</code></a>. The compiled version includes this.</li>
  <li>Add a dismiss button and the <code class="highlighter-rouge">.alert-dismissible</code> class, which adds extra padding to the right of the alert and positions the <code class="highlighter-rouge">.close</code> button.</li>
  <li>On the dismiss button, add the <code class="highlighter-rouge">data-dismiss="alert"</code> attribute, which triggers the JavaScript functionality. Be sure to use the <code class="highlighter-rouge">&lt;button&gt;</code> element with it for proper behavior across all devices.</li>
  <li>To animate alerts when dismissing them, be sure to add the <code class="highlighter-rouge">.fade</code> and <code class="highlighter-rouge">.show</code> classes.</li>
</ul>

<p>You can see this in action with a live demo:</p>

<div class="bd-example">
<div class="frmkt-alert frmkt-alert-warning frmkt-alert-dismissible frmkt-fade frmkt-show" role="alert">
  <strong>Holy guacamole!</strong> You should check in on some of those fields below.
  <button type="button" class="frmkt-close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">×</span>
  </button>
</div>
</div>
<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html"><span class="frmkt-nt">&lt;div</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"alert alert-warning alert-dismissible fade show"</span> <span class="frmkt-na">role=</span><span class="frmkt-s">"alert"</span><span class="frmkt-nt">&gt;</span>
  <span class="frmkt-nt">&lt;strong&gt;</span>Holy guacamole!<span class="frmkt-nt">&lt;/strong&gt;</span> You should check in on some of those fields below.
  <span class="frmkt-nt">&lt;button</span> <span class="frmkt-na">type=</span><span class="frmkt-s">"button"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"close"</span> <span class="frmkt-na">data-dismiss=</span><span class="frmkt-s">"alert"</span> <span class="frmkt-na">aria-label=</span><span class="frmkt-s">"Close"</span><span class="frmkt-nt">&gt;</span>
    <span class="frmkt-nt">&lt;span</span> <span class="frmkt-na">aria-hidden=</span><span class="frmkt-s">"true"</span><span class="frmkt-nt">&gt;</span><span class="frmkt-ni">&amp;times;</span><span class="frmkt-nt">&lt;/span&gt;</span>
  <span class="frmkt-nt">&lt;/button&gt;</span>
<span class="frmkt-nt">&lt;/div&gt;</span></code></pre></figure>

<h2 id="javascript-behavior"><div>JavaScript behavior<a class="frmkt-anchorjs-link frmkt-" href="#javascript-behavior" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h2>

<h3 id="triggers"><div>Triggers<a class="frmkt-anchorjs-link frmkt-" href="#triggers" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h3>

<p>Enable dismissal of an alert via JavaScript:</p>

<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-js" data-lang="js"><span class="frmkt-nx">$</span><span class="frmkt-p">(</span><span class="frmkt-s1">'.alert'</span><span class="frmkt-p">).</span><span class="frmkt-nx">alert</span><span class="frmkt-p">()</span></code></pre></figure>

<p>Or with <code class="highlighter-rouge">data</code> attributes on a button <strong>within the alert</strong>, as demonstrated above:</p>

<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html"><span class="frmkt-nt">&lt;button</span> <span class="frmkt-na">type=</span><span class="frmkt-s">"button"</span> <span class="frmkt-na">class=</span><span class="frmkt-s">"close"</span> <span class="frmkt-na">data-dismiss=</span><span class="frmkt-s">"alert"</span> <span class="frmkt-na">aria-label=</span><span class="frmkt-s">"Close"</span><span class="frmkt-nt">&gt;</span>
  <span class="frmkt-nt">&lt;span</span> <span class="frmkt-na">aria-hidden=</span><span class="frmkt-s">"true"</span><span class="frmkt-nt">&gt;</span><span class="frmkt-ni">&amp;times;</span><span class="frmkt-nt">&lt;/span&gt;</span>
<span class="frmkt-nt">&lt;/button&gt;</span></code></pre></figure>

<p>Note that closing an alert will remove it from the DOM.</p>

<h3 id="methods"><div>Methods<a class="frmkt-anchorjs-link frmkt-" href="#methods" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h3>

<table>
  <thead>
    <tr>
      <th>Method</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code class="highlighter-rouge">$().alert()</code></td>
      <td>Makes an alert listen for click events on descendant elements which have the <code class="highlighter-rouge">data-dismiss="alert"</code> attribute. (Not necessary when using the data-api’s auto-initialization.)</td>
    </tr>
    <tr>
      <td><code class="highlighter-rouge">$().alert('close')</code></td>
      <td>Closes an alert by removing it from the DOM. If the <code class="highlighter-rouge">.fade</code> and <code class="highlighter-rouge">.show</code> classes are present on the element, the alert will fade out before it is removed.</td>
    </tr>
    <tr>
      <td><code class="highlighter-rouge">$().alert('dispose')</code></td>
      <td>Destroys an element’s alert.</td>
    </tr>
  </tbody>
</table>

<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-js" data-lang="js"><span class="frmkt-nx">$</span><span class="frmkt-p">(</span><span class="frmkt-s2">".alert"</span><span class="frmkt-p">).</span><span class="frmkt-nx">alert</span><span class="frmkt-p">(</span><span class="frmkt-s1">'close'</span><span class="frmkt-p">)</span></code></pre></figure>

<h3 id="events"><div>Events<a class="frmkt-anchorjs-link frmkt-" href="#events" aria-label="Anchor" data-anchorjs-icon="#" style="padding-left: 0.375em;"></a></div></h3>

<p>framekit’s alert plugin exposes a few events for hooking into alert functionality.</p>

<table>
  <thead>
    <tr>
      <th>Event</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code class="highlighter-rouge">close.bs.alert</code></td>
      <td>This event fires immediately when the <code>close</code> instance method is called.</td>
    </tr>
    <tr>
      <td><code class="highlighter-rouge">closed.bs.alert</code></td>
      <td>This event is fired when the alert has been closed (will wait for CSS transitions to complete).</td>
    </tr>
  </tbody>
</table>

<div class="bd-clipboard"><button class="frmkt-btn-clipboard" title="" data-original-title="Copy to clipboard">Copy</button></div><figure class="highlight"><pre><code class="frmkt-language-js" data-lang="js"><span class="frmkt-nx">$</span><span class="frmkt-p">(</span><span class="frmkt-s1">'#myAlert'</span><span class="frmkt-p">).</span><span class="frmkt-nx">on</span><span class="frmkt-p">(</span><span class="frmkt-s1">'closed.bs.alert'</span><span class="frmkt-p">,</span> <span class="frmkt-kd">function</span> <span class="frmkt-p">()</span> <span class="frmkt-p">{</span>
  <span class="frmkt-c1">// do something…</span>
<span class="frmkt-p">})</span></code></pre></figure>
</main>