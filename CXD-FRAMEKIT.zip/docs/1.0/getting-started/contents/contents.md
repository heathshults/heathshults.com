---
layout: docs
title: Contents
description: Discover what's included in framekit, including our precompiled and source code flavors. Remember, framekit's JavaScript plugins require jQuery.
group: getting-started
toc: true
---

## Precompiled framekit

Once downloaded, unzip the compressed folder and you'll see something like this:

<!-- NOTE: This info is intentionally duplicated in the README. Copy any changes made here over to the README too. -->

```plaintext
framekit/
├── css/
│   ├── framekit.css
│   ├── framekit.css.map
│   ├── framekit.min.css
│   ├── framekit.min.css.map
│   ├── framekit-grid.css
│   ├── framekit-grid.css.map
│   ├── framekit-grid.min.css
│   ├── framekit-grid.min.css.map
│   ├── framekit-reboot.css
│   ├── framekit-reboot.css.map
│   ├── framekit-reboot.min.css
│   └── framekit-reboot.min.css.map
└── js/
    ├── framekit.bundle.js
    ├── framekit.bundle.min.js
    ├── framekit.js
    └── framekit.min.js
```

This is the most basic form of framekit: precompiled files for quick drop-in usage in nearly any web project. We provide compiled CSS and JS (`framekit.*`), as well as compiled and minified CSS and JS (`framekit.min.*`). CSS [source maps](https://developers.google.com/web/tools/chrome-devtools/javascript/source-maps) (`framekit.*.map`) are available for use with certain browsers' developer tools. Bundled JS files (`framekit.bundle.js` and minified `framekit.bundle.min.js`) include [Popper](https://popper.js.org/), but not [jQuery](https://jquery.com/).

## CSS files

framekit includes a handful of options for including some or all of our compiled CSS.

<table class="frmkt-table frmkt-table-bordered">
  <thead>
    <tr>
      <th scope="col">CSS files</th>
      <th scope="col">Layout</th>
      <th scope="col">Content</th>
      <th scope="col">Components</th>
      <th scope="col">Utilities</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit.css</code></div>
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit.min.css</code></div>
      </th>
      <td class="frmkt-text-success">Included</td>
      <td class="frmkt-text-success">Included</td>
      <td class="frmkt-text-success">Included</td>
      <td class="frmkt-text-success">Included</td>
    </tr>
    <tr>
      <th scope="row">
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit-grid.css</code></div>
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit-grid.min.css</code></div>
      </th>
      <td><a class="frmkt-text-warning" href="{{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/layout/grid/">Only grid system</a></td>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
      <td><a class="frmkt-text-warning" href="{{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/utilities/flex/">Only flex utilities</a></td>
    </tr>
    <tr>
      <th scope="row">
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit-reboot.css</code></div>
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit-reboot.min.css</code></div>
      </th>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
      <td><a class="frmkt-text-warning" href="{{ shared.server.baseurl }}/docs/{{ shared.docs_version }}/content/reboot/">Only Reboot</a></td>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
    </tr>
  </tbody>
</table>

## JS files

Similarly, we have options for including some or all of our compiled JavaScript.

<table class="frmkt-table frmkt-table-bordered">
  <thead>
    <tr>
      <th scope="col">JS files</th>
      <th scope="col">Popper</th>
      <th scope="col">jQuery</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit.bundle.js</code></div>
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit.bundle.min.js</code></div>
      </th>
      <td class="frmkt-text-success">Included</td>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
    </tr>
    <tr>
      <th scope="row">
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit.js</code></div>
        <div><code class="frmkt-font-weight-normal frmkt-text-nowrap">framekit.min.js</code></div>
      </th>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
      <td class="frmkt-bg-light frmkt-text-muted">Not included</td>
    </tr>
  </tbody>
</table>

## framekit source code

The framekit source code download includes the precompiled CSS and JavaScript assets, along with source Sass, JavaScript, and documentation. More specifically, it includes the following and more:

```plaintext
framekit/
├── dist/
│   ├── css/
│   └── js/
├── docs/
│   └── examples/
├── js/
└── scss/
```

The `scss/` and `js/` are the source code for our CSS and JavaScript. The `dist/` folder includes everything listed in the precompiled download section above. The `docs/` folder includes the source code for our documentation, and `examples/` of framekit usage. Beyond that, any other included file provides support for packages, license information, and development.
