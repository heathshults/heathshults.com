---
layout: docs
title: Images
description: Documentation and examples for opting images into responsive behavior (so they never become larger than their parent elements) and add lightweight styles to them—all via classes.
group: content
toc: true
---

## Responsive images

Images in framekit are made responsive with `.img-fluid`. `max-width: 100%;` and `height: auto;` are applied to the image so that it scales with the parent element.

<div class="bd-example">
  <img data-src="holder.js/100px250" class="frmkt-img-fluid" alt="Generic responsive image">
</div>

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
<img src="..." class="frmkt-img-fluid" alt="Responsive image">
</code></pre>

<div class="bd-callout bd-callout-warning">
##### SVG images and IE 10

In Internet Explorer 10, SVG images with `.img-fluid` are disproportionately sized. To fix this, add `width: 100% \9;` where necessary. This fix improperly sizes other image formats, so framekit doesn't apply it automatically.
</div>


## Image thumbnails

In addition to our [border-radius utilities]({{shared.server.baseurl }}/docs/{{ shared.docs_version }}/utilities/borders/), you can use `.img-thumbnail` to give an image a rounded 1px border appearance.

<div class="bd-example bd-example-images">
  <img data-src="holder.js/200x200" class="frmkt-img-thumbnail" alt="A generic square placeholder image with a white border around it, making it resemble a photograph taken with an old instant camera">
</div>

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
<img src="..." alt="..." class="frmkt-img-thumbnail">
</code></pre>

## Aligning images

Align images with the [helper float classes]({{shared.server.baseurl }}/docs/{{ shared.docs_version }}/utilities/float) or [text alignment classes]({{shared.server.baseurl }}/docs/{{ shared.docs_version }}/utilities/text/#text-alignment). `block`-level images can be centered using [the `.mx-auto` margin utility class]({{shared.server.baseurl }}/docs/{{ shared.docs_version }}/utilities/spacing/#horizontal-centering).

<div class="bd-example bd-example-images">
  <img data-src="holder.js/200x200" class="frmkt-rounded frmkt-float-left" alt="A generic square placeholder image with rounded corners">
  <img data-src="holder.js/200x200" class="frmkt-rounded frmkt-float-right" alt="A generic square placeholder image with rounded corners">
</div>

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
<img src="..." class="frmkt-rounded frmkt-float-left" alt="...">
<img src="..." class="frmkt-rounded frmkt-float-right" alt="...">
</code></pre>

<div class="bd-example bd-example-images">
  <img data-src="holder.js/200x200" class="frmkt-rounded frmkt-mx-auto frmkt-d-block" alt="A generic square placeholder image with rounded corners">
</div>

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
<img src="..." class="frmkt-rounded frmkt-mx-auto frmkt-d-block" alt="...">
</code></pre>

<div class="bd-example bd-example-images">
  <div class="frmkt-text-center">
    <img data-src="holder.js/200x200" class="frmkt-rounded" alt="A generic square placeholder image with rounded corners">
  </div>
</div>

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
<div class="frmkt-text-center">
  <img src="..." class="frmkt-rounded" alt="...">
</div>
</code></pre>


## Picture

If you are using the `<picture>` element to specify multiple `<source>` elements for a specific `<img>`, make sure to add the `.img-*` classes to the `<img>` and not to the `<picture>` tag.

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
​<picture>
  <source srcset="..." type="image/svg+xml">
  <img src="..." class="frmkt-img-fluid frmkt-img-thumbnail" alt="...">
</picture>
</code></pre>
