---
layout: docs
title: Figures
description: Documentation and examples for displaying related images and text with the figure component in framekit.
group: content
---

Anytime you need to display a piece of content—like an image with an optional caption, consider using a `<figure>`.

Use the included `.figure` , `.figure-img` and `.figure-caption` classes to provide some baseline styles for the HTML5 `<figure>` and `<figcaption>` elements. Images in figures have no explicit size, so be sure to add the `.img-fluid` class to your `<img>` to make it responsive.

<div class="bd-example">
<figure class="frmkt-figure">
  <img data-src="holder.js/400x300" class="frmkt-figure-img frmkt-img-fluid frmkt-rounded" alt="A generic square placeholder image with rounded corners in a figure.">
  <figcaption class="frmkt-figure-caption">A caption for the above image.</figcaption>
</figure>
</div>


Aligning the figure's caption is easy with our [text utilities]({{shared.server.baseurl }}/docs/{{ shared.docs_version }}/utilities/text/#text-alignment).

<div class="bd-example">
<figure class="frmkt-figure">
  <img data-src="holder.js/400x300" class="frmkt-figure-img frmkt-img-fluid frmkt-rounded" alt="A generic square placeholder image with rounded corners in a figure.">
  <figcaption class="frmkt-figure-caption frmkt-text-right">A caption for the above image.</figcaption>
</figure>
</div>

