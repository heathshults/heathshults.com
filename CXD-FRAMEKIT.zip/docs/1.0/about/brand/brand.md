---
layout: docs
title: Brand guidelines
description: Documentation and examples for framekit's logo and brand usage guidelines.
group: about
toc: true
---

Have a need for framekit's brand resources? Great! We have only a few guidelines we follow, and in turn ask you to follow as well. These guidelines were inspired by MailChimp's [Brand Assets](https://mailchimp.com/about/brand-assets/).

## Mark and logo

Use either the framekit mark (a capital **B**) or the standard logo (just **framekit**). It should always appear in San Francisco Display Semibold. **Do not use the Twitter bird** in association with framekit.

<div class="frmkt-brand-logos">
  <div class="frmkt-brand-item">
    <img class="frmkt-svg" src="{{shared.server.baseurl }}/assets/brand/framekit-solid.svg" alt="framekit" width="144" height="144">
  </div>
  <div class="frmkt-brand-item frmkt-inverse">
    <img class="frmkt-svg" src="{{shared.server.baseurl }}/assets/brand/framekit-outline.svg" alt="framekit" width="144" height="144">
  </div>
</div>
<div class="frmkt-brand-logos">
  <div class="frmkt-brand-item">
    <span class="frmkt-h1">framekit</span>
  </div>
  <div class="frmkt-brand-item frmkt-inverse">
    <span class="frmkt-h1">framekit</span>
  </div>
</div>

## Download mark

Download the framekit mark in one of three styles, each available as an SVG file. Right click, Save as.

<div class="frmkt-brand-logos">
  <div class="frmkt-brand-item">
    <img class="frmkt-svg" src="{{shared.server.baseurl }}/assets/brand/framekit-solid.svg" alt="framekit" width="144" height="144">
  </div>
  <div class="frmkt-brand-item frmkt-inverse">
    <img class="frmkt-svg" src="{{shared.server.baseurl }}/assets/brand/framekit-outline.svg" alt="framekit" width="144" height="144">
  </div>
  <div class="frmkt-brand-item frmkt-inverse">
    <img class="frmkt-svg" src="{{shared.server.baseurl }}/assets/brand/framekit-punchout.svg" alt="framekit" width="144" height="144">
  </div>
</div>

## Name

The project and framework should always be referred to as **framekit**. No Twitter before it, no capital _s_, and no abbreviations except for one, a capital **B**.

<div class="frmkt-brand-logos">
  <div class="frmkt-brand-item">
    <span class="frmkt-h3">framekit</span>
    <strong class="frmkt-text-success">Right</strong>
  </div>
  <div class="frmkt-brand-item">
    <span class="frmkt-h3 frmkt-text-muted">BootStrap</span>
    <strong class="frmkt-text-warning">Wrong</strong>
  </div>
  <div class="frmkt-brand-item">
    <span class="frmkt-h3 frmkt-text-muted">Twitter framekit</span>
    <strong class="frmkt-text-warning">Wrong</strong>
  </div>
</div>

## Colors

Our docs and branding use a handful of primary colors to differentiate what *is* framekit from what *is in* framekit. In other words, if it's purple, it's representative of framekit.

<div class="frmkt-brand">
  <div class="frmkt-color-swatches">
    <div class="frmkt-color-swatch frmkt-purple"></div>
    <div class="frmkt-color-swatch frmkt-purple-light"></div>
    <div class="frmkt-color-swatch frmkt-purple-lighter"></div>
    <div class="frmkt-color-swatch frmkt-gray"></div>
  </div>
</div>
