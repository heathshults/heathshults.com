 Example

Badges scale to match the size of the immediate parent element by using relative font sizing and `em` units.

<div class="bd-example">
<div class="frmkt-h1">Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></div>
<div class="frmkt-h2">Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></div>
<div class="frmkt-h3">Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></div>
<div class="frmkt-h4">Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></div>
<div class="frmkt-h5">Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></div>
<div class="frmkt-h6">Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></div>
</div>

```html
<h1>Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></h1>
<h2>Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></h2>
<h3>Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></h3>
<h4>Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></h4>
<h5>Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></h5>
<h6>Example heading <span class="frmkt-badge frmkt-badge-secondary">New</span></h6>
```

Badges can be used as part of links or buttons to provide a counter.

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
&lt;button type="button" class="frmkt-btn frmkt-btn-primary"&gt;
  Notifications &lt;span class="frmkt-badge frmkt-badge-light"&gt;4&lt;/span&gt;
&lt;/button&gt;
&lt;/div&gt;
</code></pre></figure>

Note that depending on how they are used, badges may be confusing for users of screen readers and similar assistive technologies. While the styling of badges provides a visual cue as to their purpose, these users will simply be presented with the content of the badge. Depending on the specific situation, these badges may seem like random additional words or numbers at the end of a sentence, link, or button.

Unless the context is clear (as with the "Notifications" example, where it is understood that the "4" is the number of notifications), consider including additional context with a visually hidden piece of additional text.

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
<button type="button" class="frmkt-btn frmkt-btn-primary">
  Profile <span class="frmkt-badge frmkt-badge-light">9</span>
  <span class="frmkt-sr-only">unread messages</span>
</button>
</div>
</code></pre></figure>

## Contextual variations

Add any of the below mentioned modifier classes to change the appearance of a badge.

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
{{each shared.themeColors as |color|}}
<span class="frmkt-badge frmkt-badge-{{ frmkt-shared.color.name frmkt-}}">{{capitalize shared.color.name}}</span>{{/each}}
</div>
</code></pre></figure>

{{include 'callout-warning-color-assistive-technologies.md'}}

## Pill badges

Use the `.badge-pill` modifier class to make badges more rounded (with a larger `border-radius` and additional horizontal `padding`). Useful if you miss the badges from v3.

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
{{each shared.themeColors as |color|}}
<span class="frmkt-badge frmkt-badge-pill frmkt-badge-{{ frmkt-shared.color.name frmkt-}}">{{capitalize shared.color.name}}</span>{{/each}}
</div>
</code></pre></figure>

## Links

Using the contextual `.badge-*` classes on an `<a>` element quickly provide _actionable_ badges with hover and focus states.

<figure class="highlight"><pre><code class="frmkt-language-html" data-lang="html">
{{each shared.themeColors as |color|}}
<a href="javascript:void(0)" class="frmkt-badge frmkt-badge-{{ frmkt-shared.color.name frmkt-}}">{{capitalize shared.color.name}}</a>{{/each}}
</div>
</code></pre></figure>
