---
layout: docs
title: Jumbotron
description: Lightweight, flexible component for showcasing hero unit style content.
group: components
---

A lightweight, flexible component that can optionally extend the entire viewport to showcase key marketing messages on your shared.

{{capture 'example'}}
<div class="frmkt-jumbotron">
  <h1 class="frmkt-display-4">Hello, world!</h1>
  <p class="bd-lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
  <hr class="frmkt-my-4">
  <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
  <a class="frmkt-btn frmkt-btn-primary frmkt-btn-lg" href="javascript:void(0)" role="button">Learn more</a>
</div>
</div>
{{include 'example' content=example}}

To make the jumbotron full width, and without rounded corners, add the `.jumbotron-fluid` modifier class and add a `.container` or `.container-fluid` within.

{{capture 'example'}}
<div class="frmkt-jumbotron frmkt-jumbotron-fluid">
  <div class="frmkt-container">
    <h1 class="frmkt-display-4">Fluid jumbotron</h1>
    <p class="bd-lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
  </div>
</div>
</div>
{{include 'example' content=example}}
