const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const nunjucks = require('nunjucks')
const glpNjk = require('gulp-nunjucks')
const methodOverride = require('method-override')
var nunjucksMd = require('gulp-nunjucks-md')
var markdown = require('nunjucks-markdown')
var marked = require('marked')
var pathz = require('./pathalizer')
// console.log(JSON.stringify(pathz))
var CaptureTag = require('nunjucks-capture');
// var njkFilters = require('nunjucks-filters')()
var src = path.resolve(path, __dirname, 'src')
var templates = path.resolve(path, __dirname, 'src/_templates')
var public = path.resolve(path, __dirname, 'docs/1.0')
var globalDataFile = path.resolve(path, __dirname, 'src/data/global.json')


const app = express()
const PORT_NUMBER = 4588
const data = globalDataFile
const currentYear = new Date()

app.set('_templates', path.join(__dirname, 'src/_templates'))
app.set(templates)
// const env = nunjucks.configure(app.get('src/_templates'), {

const env = nunjucks.configure(app.get(templates), {
  autoescape: true,
  noCache: true,
  watch: true,
  express: app
})

env.addGlobal(JSON.stringify(pathz));  
console.log(pathz.pNf) 


env.addFilter('emoji',
  function() {
      return '(⌐■_■)';
  });

env.addExtension('CaptureTag', new CaptureTag())
markdown.register(env, marked)

// env.addExtension('markdown', new Markdown(env, renderMarkdown))

marked.setOptions({
renderer: new marked.Renderer(),
  gfm: true,
  tables: true,
  breaks: false,
  pendantic: false,
  sanitize: true,
  smartLists: true,
  smartypants: false

})

app.set('view engine', 'html')

app.use(methodOverride('_method'))
app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static(path.join(__dirname, 'docs'))) // public hosted files

app.get('src', function(req, res) {
    res.render('index', {
      env: env,
      data: data,
      currentYear: currentYear
    })
})

console.log(env)

app.listen(PORT_NUMBER,
    function() {
        console.log('templates: ' + pathz.docBase + '\nExample app listening on port ' + PORT_NUMBER)
    })
    